#!/usr/bin/env python3
from __future__ import annotations

import argparse, json, os, sys
from pathlib import Path

import cv2

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.signature.fit import fit_std
from core.signature.model_io import load_model
from core.pipeline.analyzer import evaluate, evaluate_multi, evaluate_registration_multi
from core.model_registry import compute_cfg_hash, load_std_models, load_pattern_baseline, load_expected_ink_count
from core.types import Decision, GateResult
from core.mode.mode_tracker import load_state, save_state, update_and_check_shift
from core.reason_codes import reason_codes, reason_messages


def load_cfg(p: str) -> dict:
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def main():
    ap = argparse.ArgumentParser()

    ap.add_argument("--cfg", default=str(Path("configs") / "default.json"))
    ap.add_argument("--tests", nargs="+", required=True)
    ap.add_argument("--out", default="")

    # Single-model inputs
    ap.add_argument("--std", default="", help="STD image path (if not using --std_model)")
    ap.add_argument("--std_model", default="", help="STD model prefix (prefix.npz + prefix.json)")

    # Multi-mode inputs (A-plan)
    ap.add_argument("--std_model_low", default="", help="LOW model prefix")
    ap.add_argument("--std_model_mid", default="", help="MID model prefix")
    ap.add_argument("--std_model_high", default="", help="HIGH model prefix")

    # SKU-level state for sampling QC
    ap.add_argument("--sku", default="", help="SKU id for mode shift tracking or registry lookup")
    ap.add_argument("--ink", default="INK_DEFAULT", help="Ink name for registry lookup")
    ap.add_argument("--models_root", default=str(Path("models")), help="Models root for index.json")
    ap.add_argument("--state_dir", default=None, help="Directory to store SKU states")
    ap.add_argument("--phase", default="INSPECTION", choices=["INSPECTION", "STD_REGISTRATION"])
    ap.add_argument("--expected_ink_count", type=int, default=None)

    args = ap.parse_args()
    if not args.state_dir:
        env_state_dir = os.getenv("LENS_STATE_DIR")
        args.state_dir = env_state_dir if env_state_dir else str(Path("state"))
    cfg = load_cfg(args.cfg)

    # Determine mode: multi if all three provided
    use_multi = bool(args.std_model_low and args.std_model_mid and args.std_model_high)
    use_registry = False

    std_model_single = None
    std_models = None
    pattern_baseline = None
    baseline_reasons: list = []
    expected_ink_count_registry = None

    if use_multi:
        std_models = {
            "LOW": load_model(args.std_model_low),
            "MID": load_model(args.std_model_mid),
            "HIGH": load_model(args.std_model_high),
        }
        if not args.sku:
            # SKU is not strictly required, but recommended for mode shift flag.
            pass
    else:
        use_registry = bool(args.sku) and not args.std_model and not args.std
        if use_registry:
            cfg_hash = compute_cfg_hash(cfg)
            std_models, reasons = load_std_models(
                args.models_root,
                args.sku,
                args.ink,
                cfg_hash=cfg_hash,
            )
            pattern_baseline, baseline_reasons = load_pattern_baseline(
                args.models_root,
                args.sku,
                args.ink,
            )
            expected_ink_count_registry = load_expected_ink_count(
                args.models_root,
                args.sku,
                args.ink,
            )
            if std_models is None:
                use_multi = True
            else:
                use_multi = True
        else:
            reasons = []
        if args.std_model:
            std_model_single = load_model(args.std_model)
        else:
            if not args.std:
                if not use_registry:
                    raise SystemExit("Provide --std_model or --std (or use --std_model_low/mid/high for multi-mode)")
            else:
                std_bgr = cv2.imread(args.std)
                if std_bgr is None:
                    raise SystemExit(f"Failed to read STD: {args.std}")
                std_model_single = fit_std(
                    std_bgr,
                    R=cfg["polar"]["R"],
                    T=cfg["polar"]["T"],
                    r_start=cfg["signature"]["r_start"],
                    r_end=cfg["signature"]["r_end"],
                )

    results = []

    # load sku state once (sampling QC: small volume)
    state = None
    if use_multi and args.phase == "INSPECTION" and cfg.get("mode_stability", {}).get("enabled", True) and args.sku:
        state = load_state(args.state_dir, args.sku)

    for p in args.tests:
        bgr = cv2.imread(p)
        if bgr is None:
            results.append({"path": p, "error": "read_failed"})
            continue
        ok_log_context = {
            "sku": args.sku,
            "ink": args.ink,
            "models_root": args.models_root,
            "result_path": p,
            "expected_ink_count_input": args.expected_ink_count,
            "expected_ink_count_registry": expected_ink_count_registry,
        }

        if use_multi:
            if std_models is None:
                label = "RETAKE" if args.phase == "INSPECTION" else "STD_RETAKE"
                codes = reason_codes(reasons or ["MODEL_NOT_FOUND"])
                messages = reason_messages(reasons or ["MODEL_NOT_FOUND"])
                dec = Decision(
                    label=label,
                    reasons=reasons or ["MODEL_NOT_FOUND"],
                    reason_codes=codes,
                    reason_messages=messages,
                    gate=GateResult(passed=False, reasons=reasons or ["MODEL_NOT_FOUND"], scores={}),
                    signature=None,
                    anomaly=None,
                    phase=args.phase,
                )
                if reasons:
                    dec.debug = {"model_loading": {"reasons": reasons}}
            else:
                if args.phase == "STD_REGISTRATION":
                    dec = evaluate_registration_multi(bgr, std_models, cfg)
                else:
                    dec, mode_sigs = evaluate_multi(
                        bgr,
                        std_models,
                        cfg,
                        pattern_baseline=pattern_baseline,
                        ok_log_context=ok_log_context,
                    )
            # mode shift flag (only when best_mode exists)
            if (
                state is not None
                and dec.best_mode
                and args.phase == "INSPECTION"
                and cfg.get("mode_stability", {}).get("emit_shift_flag", True)
            ):
                shift = update_and_check_shift(state, dec.best_mode, window=int(cfg["mode_stability"].get("window", 10)))
                dec.mode_shift = shift
            if baseline_reasons and dec.debug is not None:
                dec.debug.setdefault("baseline_reasons", baseline_reasons)
            results.append({"path": p, "decision": dec.to_dict()})
        else:
            if args.phase == "STD_REGISTRATION":
                codes = reason_codes(["STD_REGISTRATION_REQUIRES_MULTI"])
                messages = reason_messages(["STD_REGISTRATION_REQUIRES_MULTI"])
                dec = Decision(
                    label="STD_RETAKE",
                    reasons=["STD_REGISTRATION_REQUIRES_MULTI"],
                    reason_codes=codes,
                    reason_messages=messages,
                    gate=GateResult(passed=False, reasons=["STD_REGISTRATION_REQUIRES_MULTI"], scores={}),
                    signature=None,
                    anomaly=None,
                    phase=args.phase,
                )
            else:
                dec = evaluate(
                    bgr,
                    std_model_single,
                    cfg,
                    pattern_baseline=pattern_baseline,
                    ok_log_context=ok_log_context,
                )
            results.append({"path": p, "decision": dec.to_dict()})

    if state is not None:
        save_state(args.state_dir, state, window=int(cfg["mode_stability"].get("window", 10)))

    payload = {
        "cfg": cfg,
        "results": results,
        "multi_mode": use_multi,
        "sku": args.sku,
        "ink": args.ink,
        "phase": args.phase,
    }
    s = json.dumps(payload, ensure_ascii=False, indent=2)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(s)
    print(s)


if __name__ == "__main__":
    main()
