#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

import cv2

import sys
from pathlib import Path as _Path

sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))

from core.signature.fit import fit_std, fit_std_multi
from core.signature.model_io import save_model


def _load_cfg(path: str) -> Dict[str, Any]:
    p = Path(path)
    data = json.loads(p.read_text(encoding="utf-8"))
    return data


def _cfg_hash(cfg: Dict[str, Any]) -> str:
    raw = json.dumps(cfg, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _now_tag() -> str:
    return datetime.now().strftime("v%Y%m%d_%H%M%S")


def _ensure_index(index_path: Path) -> Dict[str, Any]:
    if index_path.exists():
        return json.loads(index_path.read_text(encoding="utf-8"))
    return {"schema_version": "1.0", "updated_at": "", "items": []}


def _update_index(
    index_data: Dict[str, Any],
    *,
    sku: str,
    ink: str,
    mode: str,
    rel_path: str,
    created_by: str | None,
    notes: str | None,
    expected_ink_count: int | None,
) -> Dict[str, Any]:
    items = index_data.get("items", [])
    entry = None
    for item in items:
        if item.get("sku") == sku and item.get("ink") == ink:
            entry = item
            break

    if entry is None:
        entry = {
            "sku": sku,
            "ink": ink,
            "active": {},
            "status": "INCOMPLETE",
            "notes": notes or "",
            "created_by": created_by or "",
            "created_at": datetime.now().isoformat(),
        }
        items.append(entry)

    entry.setdefault("active", {})[mode] = rel_path
    entry["notes"] = notes or entry.get("notes", "")
    entry["created_by"] = created_by or entry.get("created_by", "")
    if expected_ink_count is not None:
        entry["expected_ink_count"] = int(expected_ink_count)

    active = entry.get("active", {})
    if all(active.get(m) for m in ["LOW", "MID", "HIGH"]):
        entry["status"] = "ACTIVE"
    else:
        entry["status"] = "INCOMPLETE"

    index_data["items"] = items
    index_data["updated_at"] = datetime.now().isoformat()
    return index_data


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sku", required=True)
    ap.add_argument("--ink", default="INK_DEFAULT")
    ap.add_argument("--mode", required=True, choices=["LOW", "MID", "HIGH"])
    ap.add_argument("--stds", nargs="+", required=True)
    ap.add_argument("--cfg", default=str(Path("configs") / "default.json"))
    ap.add_argument("--models_root", default=str(Path("models")))
    ap.add_argument("--created_by", default="")
    ap.add_argument("--notes", default="")
    ap.add_argument("--expected_ink_count", type=int, default=None)
    args = ap.parse_args()

    cfg = _load_cfg(args.cfg)
    tag = _now_tag()
    models_root = Path(args.models_root)
    version_dir = models_root / args.sku / args.ink / args.mode / tag
    version_dir.mkdir(parents=True, exist_ok=True)

    bgrs: List[Any] = []
    for p in args.stds:
        img = cv2.imread(p)
        if img is None:
            raise SystemExit(f"Failed to read STD image: {p}")
        bgrs.append(img)

    if len(bgrs) == 1:
        model = fit_std(
            bgrs[0],
            R=cfg["polar"]["R"],
            T=cfg["polar"]["T"],
            r_start=cfg["signature"]["r_start"],
            r_end=cfg["signature"]["r_end"],
        )
    else:
        model = fit_std_multi(
            bgrs,
            R=cfg["polar"]["R"],
            T=cfg["polar"]["T"],
            r_start=cfg["signature"]["r_start"],
            r_end=cfg["signature"]["r_end"],
        )

    save_model(model, str(version_dir / "model"))

    meta = {
        "schema_version": "1.0",
        "sku": args.sku,
        "ink": args.ink,
        "mode": args.mode,
        "version": tag,
        "std_images": [str(p) for p in args.stds],
        "engine": {"engine_version": "v7", "cfg_hash": _cfg_hash(cfg)},
        "created_by": args.created_by,
        "created_at": datetime.now().isoformat(),
        "notes": args.notes,
    }
    (version_dir / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    index_path = models_root / "index.json"
    index_data = _ensure_index(index_path)
    rel_path = str((version_dir.relative_to(models_root)).as_posix())
    index_data = _update_index(
        index_data,
        sku=args.sku,
        ink=args.ink,
        mode=args.mode,
        rel_path=rel_path,
        created_by=args.created_by,
        notes=args.notes,
        expected_ink_count=args.expected_ink_count,
    )
    index_path.write_text(json.dumps(index_data, ensure_ascii=False, indent=2), encoding="utf-8")

    print(
        json.dumps(
            {
                "saved_dir": str(version_dir),
                "index": str(index_path),
                "status": next(
                    (i["status"] for i in index_data.get("items", []) if i.get("sku") == args.sku and i.get("ink") == args.ink),
                    "",
                ),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
