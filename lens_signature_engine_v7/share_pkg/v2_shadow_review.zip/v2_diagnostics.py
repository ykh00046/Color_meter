from __future__ import annotations

from typing import Any, Dict, List, Tuple

import numpy as np

from ..geometry.lens_geometry import detect_lens_circle
from ..signature.radial_signature import to_polar
from ..utils import bgr_to_lab
from .preprocess import build_roi_mask, sample_ink_candidates
from .ink_segmentation import kmeans_segment
from .ink_metrics import build_cluster_stats


def build_v2_diagnostics(
    bgr,
    cfg: Dict[str, Any],
    expected_ink_count: int | None,
    expected_ink_count_registry: int | None,
    expected_ink_count_input: int | None,
) -> Dict[str, Any] | None:
    if expected_ink_count is None:
        return None

    v2_cfg = cfg.get("v2_ink", {})
    if not v2_cfg.get("enabled", True):
        return None

    warnings: List[str] = []
    if (
        expected_ink_count_input is not None
        and expected_ink_count_registry is not None
        and expected_ink_count_input != expected_ink_count_registry
    ):
        warnings.append("EXPECTED_INK_COUNT_OVERRIDE")

    geom = detect_lens_circle(bgr)
    polar = to_polar(bgr, geom, R=cfg["polar"]["R"], T=cfg["polar"]["T"])
    lab = bgr_to_lab(polar).astype(np.float32)

    r_start = float(v2_cfg.get("roi_r_start", cfg["anomaly"]["r_start"]))
    r_end = float(v2_cfg.get("roi_r_end", cfg["anomaly"]["r_end"]))
    roi_mask, roi_meta = build_roi_mask(
        lab.shape[0],
        lab.shape[1],
        r_start,
        r_end,
        center_excluded_frac=float(cfg["anomaly"]["center_frac"]),
    )

    rng_seed = v2_cfg.get("rng_seed", None)
    samples, sampling_meta, sampling_warnings = sample_ink_candidates(
        lab,
        roi_mask,
        cfg,
        rng_seed=rng_seed,
    )
    sampling_warnings = sampling_warnings or []

    k = int(expected_ink_count)
    kmeans_attempts = int(v2_cfg.get("kmeans_attempts", 10))
    labels, centers = kmeans_segment(
        samples,
        k,
        l_weight=float(v2_cfg.get("l_weight", 0.3)),
        attempts=kmeans_attempts,
        rng_seed=rng_seed,
    )
    if labels.size == 0:
        warnings.extend(sampling_warnings)
        warnings.append("INK_SEGMENTATION_FAILED")
        return {
            "expected_ink_count": int(expected_ink_count),
            "expected_ink_count_registry": expected_ink_count_registry,
            "expected_ink_count_input": expected_ink_count_input,
            "roi": roi_meta,
            "sampling": {**sampling_meta, "warnings": sampling_warnings},
            "segmentation": {"k_used": k, "clusters": [], "quality": {}},
            "warnings": warnings,
        }

    stats = build_cluster_stats(samples, labels, k)
    min_area = stats["quality"].get("min_area_ratio", 0.0)
    min_area_warn = float(v2_cfg.get("min_area_ratio_warn", 0.03))
    d0 = float(v2_cfg.get("separation_d0", 3.0))
    k_sig = float(v2_cfg.get("separation_k", 1.0))
    seg_warnings: List[str] = []
    samp_warnings: List[str] = list(sampling_warnings)
    if min_area < min_area_warn:
        seg_warnings.append("INK_CLUSTER_TOO_SMALL")

    min_delta = float(stats["quality"].get("min_deltaE_between_clusters", 0.0))
    if min_delta < d0:
        seg_warnings.append("INK_CLUSTER_OVERLAP_HIGH")

    # separation margin (positive = safer, negative = overlap)
    sep_margin = float((min_delta - d0) / max(k_sig, 1e-6))
    stats["quality"]["separation_margin"] = sep_margin

    warnings = seg_warnings + samp_warnings

    diagnostics = {
        "expected_ink_count": int(expected_ink_count),
        "expected_ink_count_registry": expected_ink_count_registry,
        "expected_ink_count_input": expected_ink_count_input,
        "roi": roi_meta,
        "sampling": {**sampling_meta, "warnings": samp_warnings},
        "segmentation": {
            "k_used": k,
            "clusters": stats["clusters"],
            "quality": stats["quality"],
            "warnings": seg_warnings,
        },
        "warnings": warnings,
    }
    return diagnostics
