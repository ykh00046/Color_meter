﻿# v2 shadow review package

This package contains the v2.0 shadow ink segmentation implementation (v7-style) and a sample output.

Sample result:
- inspect_v2_shadow_sample_r1.json generated with direct std_model_low/mid/high paths
- tmp_cfg_v2_sample.json was used to bypass pattern_baseline gating for sample-only verification
- v2 diagnostics appear under decision.diagnostics.v2_diagnostics; labels/reasons unchanged (shadow mode)
- ROI effective start and warnings split are reflected in this sample
