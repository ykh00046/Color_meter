from __future__ import annotations

from typing import Any, Dict, Tuple, List
from dataclasses import asdict
from pathlib import Path
from datetime import datetime
import json

import numpy as np

from ..types import Decision, SignatureResult
from ..geometry.lens_geometry import detect_lens_circle
from ..gate.gate_engine import run_gate
from ..signature.radial_signature import to_polar, build_radial_signature
from ..signature.signature_compare import signature_compare, segment_stats, weighted_fail_ratio, band_violation_v2
from ..anomaly.angular_uniformity import angular_uniformity_score
from ..anomaly.blob_detector import detect_center_blobs
from ..anomaly.anomaly_score import score_anomaly, score_anomaly_relative
from ..anomaly.pattern_baseline import extract_pattern_features
from ..anomaly.heatmap import anomaly_heatmap
from ..anomaly.defect_classifier import classify_defect
from ..decision.decision_engine import decide
from ..utils import cie76_deltaE, bgr_to_lab
from ..reason_codes import reason_codes, reason_messages, split_reason
from ..v2.v2_diagnostics import build_v2_diagnostics


def _build_k_by_segment(R: int, segments: list, segment_k: dict, default_k: float) -> np.ndarray:
    k_arr = np.full((R, 1), float(default_k), dtype=np.float32)
    for seg in segments:
        name = seg.get("name", "")
        k = float(segment_k.get(name, default_k))
        s = int(round(float(seg["start"]) * R))
        e = int(round(float(seg["end"]) * R))
        s = max(0, min(R - 1, s))
        e = max(s + 1, min(R, e))
        k_arr[s:e, 0] = k
    return k_arr


def _evaluate_signature(test_mean: np.ndarray, std_model, cfg: Dict[str, Any]) -> SignatureResult:
    comp = signature_compare(test_mean, std_model.radial_lab_mean)
    de_curve = comp["delta_e_curve"]

    R = int(comp["test_mean_aligned"].shape[0])
    segments = cfg["signature"].get("segments", [])
    default_k = float(cfg["signature"]["band_k"])
    use_segment_k = bool(cfg["signature"].get("use_segment_k", False)) and bool(segments)
    seg_k_map = cfg["signature"].get("segment_k", {}) if use_segment_k else {}

    if use_segment_k:
        k_arr = _build_k_by_segment(R, segments, seg_k_map, default_k)
        band = band_violation_v2(
            comp["test_mean_aligned"],
            std_model.radial_lab_mean,
            getattr(std_model, "radial_lab_std", None),
            k=k_arr,
        )
    else:
        band = band_violation_v2(
            comp["test_mean_aligned"],
            std_model.radial_lab_mean,
            getattr(std_model, "radial_lab_std", None),
            k=default_k,
        )

    fail_mask = band["fail_mask"]
    base_fail_ratio = float(band["fail_ratio"])

    seg_stats = segment_stats(de_curve, fail_mask, segments) if segments else {}
    w_fail_ratio = weighted_fail_ratio(seg_stats) if seg_stats else base_fail_ratio
    use_weighted = bool(cfg["signature"].get("use_weighted_segments", False)) and bool(seg_stats)
    eff_fail_ratio = w_fail_ratio if use_weighted else base_fail_ratio

    fail_regions = np.where(fail_mask)[0].tolist()

    sig_reasons = []
    if comp["corr"] < cfg["signature"]["corr_min"]:
        sig_reasons.append("SIGNATURE_CORR_LOW")
    if comp["delta_e_p95"] > cfg["signature"]["de_p95_max"]:
        sig_reasons.append("DELTAE_P95_HIGH")
    if comp["delta_e_mean"] > cfg["signature"]["de_mean_max"]:
        sig_reasons.append("DELTAE_MEAN_HIGH")

    use_band = bool(cfg["signature"].get("use_band_model", True))
    if use_band and eff_fail_ratio > cfg["signature"]["fail_ratio_max"]:
        sig_reasons.append("BAND_VIOLATION_HIGH")

    seg_violation_reasons = []
    seg_cap = cfg["signature"].get("segment_fail_ratio_max", None)
    if seg_cap is not None and bool(seg_stats):
        for name, st in seg_stats.items():
            if float(st.get("fail_ratio", 0.0)) > float(seg_cap):
                seg_violation_reasons.append(f"SEGMENT_BAND_VIOLATION:{name}")

    return SignatureResult(
        passed=(len(sig_reasons) == 0),
        score_corr=float(comp["corr"]),
        delta_e_mean=float(comp["delta_e_mean"]),
        delta_e_p95=float(comp["delta_e_p95"]),
        fail_ratio=float(eff_fail_ratio),
        fail_regions_r=fail_regions[:200],
        reasons=sig_reasons,
        flags={"segment_violation_reasons": seg_violation_reasons},
        debug={
            "delta_e_curve": de_curve.astype(np.float32).tolist(),
            "band_fail_ratio": float(base_fail_ratio),
            "band_fail_ratio_weighted": float(w_fail_ratio),
            "segment_stats": seg_stats,
            "band_weighted_enabled": bool(use_weighted),
            "segment_k_enabled": bool(use_segment_k),
            "segment_k_map": seg_k_map,
        },
    )


def _pick_best_mode(mode_sigs: Dict[str, SignatureResult]) -> str:
    # primary: fail_ratio, then delta_e_p95, then -corr
    items = []
    for mode, sig in mode_sigs.items():
        items.append((mode, sig.fail_ratio, sig.delta_e_p95, -sig.score_corr))
    items.sort(key=lambda x: (x[1], x[2], x[3]))
    return items[0][0]


def _reason_meta(reasons: list, overrides: Dict[str, str] | None = None) -> Tuple[list, list]:
    codes = reason_codes(reasons)
    messages = []
    for r in reasons:
        code, _detail = split_reason(r)
        if overrides and code in overrides:
            messages.append(overrides[code])
        else:
            messages.append(reason_messages([r])[0])
    return codes, messages


def _mean_grad(l_map: np.ndarray) -> float:
    if l_map.size == 0:
        return 0.0
    gx = np.abs(np.diff(l_map, axis=1))
    gy = np.abs(np.diff(l_map, axis=0))
    return float((gx.mean() + gy.mean()) / 2.0)


def _compute_diagnostics(test_lab_map: np.ndarray, std_lab_mean: np.ndarray, cfg: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str], Dict[str, str]]:
    diag_cfg = cfg.get("diagnostics", {})
    dL_th = float(diag_cfg.get("delta_L_threshold", 1.0))
    da_th = float(diag_cfg.get("delta_a_threshold", 0.8))
    db_th = float(diag_cfg.get("delta_b_threshold", 0.8))
    cov_l_delta = float(diag_cfg.get("coverage_l_delta", 5.0))
    cov_pp_th = float(diag_cfg.get("coverage_delta_pp_threshold", 2.0))
    edge_th = float(diag_cfg.get("edge_sharpness_delta_threshold", 0.1))

    std_mean = std_lab_mean.mean(axis=0)
    sample_mean = test_lab_map.reshape(-1, 3).mean(axis=0)
    delta = sample_mean - std_mean

    reason_codes_extra: List[str] = []
    reason_messages_extra: Dict[str, str] = {}

    if delta[2] >= db_th:
        reason_codes_extra.append("COLOR_SHIFT_YELLOW")
        reason_messages_extra["COLOR_SHIFT_YELLOW"] = f"Color shift yellow (delta_b={delta[2]:+.2f})."
    elif delta[2] <= -db_th:
        reason_codes_extra.append("COLOR_SHIFT_BLUE")
        reason_messages_extra["COLOR_SHIFT_BLUE"] = f"Color shift blue (delta_b={delta[2]:+.2f})."
    if delta[1] >= da_th:
        reason_codes_extra.append("COLOR_SHIFT_RED")
        reason_messages_extra["COLOR_SHIFT_RED"] = f"Color shift red (delta_a={delta[1]:+.2f})."
    elif delta[1] <= -da_th:
        reason_codes_extra.append("COLOR_SHIFT_GREEN")
        reason_messages_extra["COLOR_SHIFT_GREEN"] = f"Color shift green (delta_a={delta[1]:+.2f})."
    if delta[0] <= -dL_th:
        reason_codes_extra.append("COLOR_SHIFT_DARK")
        reason_messages_extra["COLOR_SHIFT_DARK"] = f"Color shift dark (delta_L={delta[0]:+.2f})."
    elif delta[0] >= dL_th:
        reason_codes_extra.append("COLOR_SHIFT_LIGHT")
        reason_messages_extra["COLOR_SHIFT_LIGHT"] = f"Color shift light (delta_L={delta[0]:+.2f})."

    T = test_lab_map.shape[0]
    std_lab_map = np.repeat(std_lab_mean[None, :, :], T, axis=0)
    std_l = std_lab_map[..., 0]
    sample_l = test_lab_map[..., 0]
    std_l_mean = float(std_l.mean())
    sample_l_mean = float(sample_l.mean())
    std_cov = float(np.mean(std_l < (std_l_mean - cov_l_delta)))
    sample_cov = float(np.mean(sample_l < (sample_l_mean - cov_l_delta)))
    cov_delta_pp = (sample_cov - std_cov) * 100.0

    std_edge = _mean_grad(std_l)
    sample_edge = _mean_grad(sample_l)
    edge_delta = sample_edge - std_edge

    if cov_delta_pp >= cov_pp_th:
        reason_codes_extra.append("PATTERN_DOT_COVERAGE_HIGH")
        reason_messages_extra["PATTERN_DOT_COVERAGE_HIGH"] = f"Dot coverage high (delta={cov_delta_pp:+.2f}pp)."
    elif cov_delta_pp <= -cov_pp_th:
        reason_codes_extra.append("PATTERN_DOT_COVERAGE_LOW")
        reason_messages_extra["PATTERN_DOT_COVERAGE_LOW"] = f"Dot coverage low (delta={cov_delta_pp:+.2f}pp)."
    if edge_delta <= -edge_th:
        reason_codes_extra.append("PATTERN_EDGE_BLUR")
        reason_messages_extra["PATTERN_EDGE_BLUR"] = f"Edge sharpness down (delta={edge_delta:+.3f})."
    if cov_delta_pp >= cov_pp_th and edge_delta <= -edge_th:
        reason_codes_extra.append("PATTERN_DOT_SPREAD")
        reason_messages_extra["PATTERN_DOT_SPREAD"] = f"Dot spread (cov={cov_delta_pp:+.2f}pp, edge={edge_delta:+.3f})."

    diagnostics = {
        "color": {
            "overall": {
                "std_lab_mean": std_mean.astype(np.float32).tolist(),
                "sample_lab_mean": sample_mean.astype(np.float32).tolist(),
                "direction": {
                    "delta_L": float(delta[0]),
                    "delta_a": float(delta[1]),
                    "delta_b": float(delta[2]),
                },
            }
        },
        "pattern": {
            "dot": {
                "coverage_std": std_cov,
                "coverage_sample": sample_cov,
                "coverage_delta_pp": float(cov_delta_pp),
                "edge_sharpness_std": float(std_edge),
                "edge_sharpness_sample": float(sample_edge),
                "edge_sharpness_delta": float(edge_delta),
            }
        }
    }
    return diagnostics, reason_codes_extra, reason_messages_extra


def _append_ok_features(
    test_bgr,
    decision: Decision,
    cfg: Dict[str, Any],
    pattern_baseline: Dict[str, Any] | None,
    ok_log_context: Dict[str, Any] | None,
) -> None:
    if decision.phase != "INSPECTION" or decision.label != "OK":
        return
    if pattern_baseline is None or ok_log_context is None:
        return

    sku = ok_log_context.get("sku", "")
    ink = ok_log_context.get("ink", "")
    models_root = ok_log_context.get("models_root", "")
    if not (sku and ink and models_root):
        return

    baseline_path = pattern_baseline.get("path", "")
    baseline_schema = pattern_baseline.get("schema_version", "")
    active_versions = pattern_baseline.get("active_versions", {})
    baseline_id = Path(baseline_path).stem if baseline_path else "UNKNOWN"

    try:
        log_dir = Path(models_root) / "pattern_baselines" / "ok_logs" / sku / ink
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / f"OKF_{baseline_id}.jsonl"

        features = extract_pattern_features(test_bgr, cfg=cfg)
        entry = {
            "ts": datetime.now().isoformat(),
            "sku": sku,
            "ink": ink,
            "active_id": baseline_id,
            "result_path": ok_log_context.get("result_path", ""),
            "features": features,
            "baseline": {
                "pattern_baseline_path": baseline_path,
                "pattern_baseline_schema": baseline_schema,
                "active_versions": active_versions,
            },
        }
        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception as exc:
        decision.debug["ok_feature_log_failed"] = True
        decision.debug["ok_feature_log_error"] = str(exc)


def _attach_v2_diagnostics(
    test_bgr,
    decision: Decision,
    cfg: Dict[str, Any],
    ok_log_context: Dict[str, Any] | None,
) -> None:
    if decision.phase != "INSPECTION":
        return
    if ok_log_context is None:
        return
    expected_input = ok_log_context.get("expected_ink_count_input")
    expected_registry = ok_log_context.get("expected_ink_count_registry")
    expected = expected_input if expected_input is not None else expected_registry
    if expected is None:
        return
    diagnostics = build_v2_diagnostics(
        test_bgr,
        cfg,
        expected_ink_count=int(expected),
        expected_ink_count_registry=expected_registry,
        expected_ink_count_input=expected_input,
    )
    if diagnostics is None:
        return
    decision.diagnostics.setdefault("v2_diagnostics", diagnostics)


def _registration_summary(std_models: Dict[str, Any], cfg: Dict[str, Any]) -> Tuple[Dict[str, Any], list]:
    reg_cfg = cfg.get("registration", {})
    order_enabled = bool(reg_cfg.get("order_check_enabled", True))
    metric = reg_cfg.get("order_metric", "L_mean")
    direction = reg_cfg.get("order_direction", "asc")
    sep_threshold = float(reg_cfg.get("sep_threshold", 1.0))
    max_within_std = reg_cfg.get("max_within_std", None)
    max_within_val = float(max_within_std) if max_within_std is not None else None
    geom_center_max_px = reg_cfg.get("geom_center_max_px", None)
    geom_radius_max_ratio = reg_cfg.get("geom_radius_max_ratio", None)
    geom_center_max = float(geom_center_max_px) if geom_center_max_px is not None else None
    geom_radius_max = float(geom_radius_max_ratio) if geom_radius_max_ratio is not None else None
    warnings = []

    order_values: Dict[str, float] = {}
    order_ok = True
    if order_enabled:
        for mode in ["LOW", "MID", "HIGH"]:
            model = std_models.get(mode)
            if model is None:
                continue
            lab = model.radial_lab_mean
            if metric == "L_mean":
                val = float(np.mean(lab[:, 0]))
            else:
                val = float(np.mean(lab[:, 0]))
            order_values[mode] = val

        order_ok = False
        if all(m in order_values for m in ["LOW", "MID", "HIGH"]):
            if direction == "desc":
                order_ok = order_values["LOW"] > order_values["MID"] > order_values["HIGH"]
            else:
                order_ok = order_values["LOW"] < order_values["MID"] < order_values["HIGH"]

    separation = {}
    min_pairwise = None
    separation_ok = True
    if all(m in std_models for m in ["LOW", "MID", "HIGH"]):
        de_lm = cie76_deltaE(std_models["LOW"].radial_lab_mean, std_models["MID"].radial_lab_mean)
        de_mh = cie76_deltaE(std_models["MID"].radial_lab_mean, std_models["HIGH"].radial_lab_mean)
        de_lh = cie76_deltaE(std_models["LOW"].radial_lab_mean, std_models["HIGH"].radial_lab_mean)
        separation = {
            "LOW_MID": float(np.median(de_lm)),
            "MID_HIGH": float(np.median(de_mh)),
            "LOW_HIGH": float(np.median(de_lh)),
        }
        min_pairwise = min(separation.values())
        separation_ok = min_pairwise >= sep_threshold

    within_mode = {}
    unstable_modes = []
    for mode, model in std_models.items():
        std = getattr(model, "radial_lab_std", None)
        if std is None:
            within_mode[mode] = None
            continue
        val = float(np.mean(np.linalg.norm(std, axis=-1)))
        within_mode[mode] = val
        if max_within_val is not None and val > max_within_val:
            unstable_modes.append(mode)

    within_mode_ok = len(unstable_modes) == 0
    if max_within_val is None:
        within_mode_ok = None
        warnings.append("WITHIN_MODE_THRESHOLD_DISABLED")

    geom_consistency = {
        "center_drift_px": None,
        "radius_drift_ratio": None,
        "passed": None,
    }
    centers = []
    radii = []
    for model in std_models.values():
        centers.append((model.geom.cx, model.geom.cy))
        radii.append(model.geom.r)
    if centers and radii:
        cx_vals = np.array([c[0] for c in centers], dtype=np.float32)
        cy_vals = np.array([c[1] for c in centers], dtype=np.float32)
        r_vals = np.array(radii, dtype=np.float32)
        cx_mean = float(cx_vals.mean())
        cy_mean = float(cy_vals.mean())
        center_drift = np.max(np.hypot(cx_vals - cx_mean, cy_vals - cy_mean))
        r_mean = float(r_vals.mean()) if r_vals.size else 0.0
        radius_drift_ratio = float((r_vals.max() - r_vals.min()) / r_mean) if r_mean > 0 else None
        geom_consistency["center_drift_px"] = float(center_drift)
        geom_consistency["radius_drift_ratio"] = radius_drift_ratio

        if geom_center_max is not None or geom_radius_max is not None:
            passed = True
            if geom_center_max is not None and center_drift > geom_center_max:
                passed = False
            if geom_radius_max is not None and radius_drift_ratio is not None and radius_drift_ratio > geom_radius_max:
                passed = False
            geom_consistency["passed"] = passed
        else:
            warnings.append("GEOM_THRESHOLD_DISABLED")

    summary = {
        "order_enabled": order_enabled,
        "order_metric": metric,
        "order_direction": direction,
        "order_values": order_values,
        "order_ok": order_ok,
        "sep_threshold": sep_threshold,
        "separation": separation,
        "min_pairwise_separation": min_pairwise,
        "separation_ok": separation_ok,
        "within_mode_stability": within_mode,
        "within_mode_threshold": max_within_val,
        "within_mode_ok": within_mode_ok,
        "geom_consistency": geom_consistency,
        "warnings": warnings,
    }
    return summary, unstable_modes


def evaluate(
    test_bgr,
    std_model,
    cfg: Dict[str, Any],
    pattern_baseline: Dict[str, Any] | None = None,
    ok_log_context: Dict[str, Any] | None = None,
) -> Decision:
    """
    Backward compatible single-STD evaluation.
    """
    geom = detect_lens_circle(test_bgr)
    gate = run_gate(
        geom, test_bgr,
        center_off_max=cfg["gate"]["center_off_max"],
        blur_min=cfg["gate"]["blur_min"],
        illum_max=cfg["gate"]["illum_max"],
    )
    diag_on_fail = bool(cfg.get("gate", {}).get("diagnostic_on_fail", False))

    if not gate.passed and not diag_on_fail:
        codes, messages = _reason_meta(gate.reasons)
        return Decision(
            label="RETAKE",
            reasons=gate.reasons,
            reason_codes=codes,
            reason_messages=messages,
            gate=gate,
            signature=None,
            anomaly=None,
            debug={"inference_valid": False},
            phase="INSPECTION",
        )

    use_relative = bool(cfg.get("pattern_baseline", {}).get("use_relative", True))
    require_baseline = bool(cfg.get("pattern_baseline", {}).get("require", False))
    if require_baseline and use_relative and pattern_baseline is None:
        codes, messages = _reason_meta(["PATTERN_BASELINE_NOT_FOUND"])
        return Decision(
            label="RETAKE",
            reasons=["PATTERN_BASELINE_NOT_FOUND"],
            reason_codes=codes,
            reason_messages=messages,
            gate=gate,
            signature=None,
            anomaly=None,
            debug={"inference_valid": False, "baseline_missing": True},
            phase="INSPECTION",
        )

    polar = to_polar(test_bgr, geom, R=std_model.meta["R"], T=std_model.meta["T"])
    test_mean, _, _ = build_radial_signature(
        polar, r_start=cfg["signature"]["r_start"], r_end=cfg["signature"]["r_end"]
    )

    sig = _evaluate_signature(test_mean, std_model, cfg)

    ang = angular_uniformity_score(polar, r_start=cfg["anomaly"]["r_start"], r_end=cfg["anomaly"]["r_end"])
    blobs = detect_center_blobs(test_bgr, geom, frac=cfg["anomaly"]["center_frac"], min_area=cfg["anomaly"]["center_blob_min_area"])
    if use_relative and pattern_baseline is not None:
        sample_features = extract_pattern_features(test_bgr, cfg=cfg)
        anom = score_anomaly_relative(
            sample_features=sample_features,
            baseline=pattern_baseline.get("features", {}),
            margins=pattern_baseline.get("policy", {}).get("margins", cfg.get("pattern_baseline", {}).get("margins", {})),
        )
        anom.debug["abs_scores"] = {"angular_uniformity": float(ang), "center_blob_count": float(blobs["blob_count"])}
        anom.debug["blob_debug"] = blobs
    else:
        anom = score_anomaly(
            angular_uniformity=ang,
            center_blob_count=int(blobs["blob_count"]),
            angular_unif_max=cfg["anomaly"]["angular_unif_max"],
            center_blob_max=cfg["anomaly"]["center_blob_max"],
            blob_debug=blobs,
        )

    label, reasons = decide(gate, sig, anom)
    test_lab_map = bgr_to_lab(polar)
    diagnostics, extra_codes, extra_messages = _compute_diagnostics(test_lab_map, std_model.radial_lab_mean, cfg)
    if pattern_baseline is not None:
        diagnostics.setdefault("references", {})
        diagnostics["references"]["pattern_baseline_path"] = pattern_baseline.get("path", "")
        diagnostics["references"]["pattern_baseline_schema"] = pattern_baseline.get("schema_version", "")
        diagnostics["references"]["pattern_baseline_active_versions"] = pattern_baseline.get("active_versions", {})
    if label != "OK":
        reasons = reasons + extra_codes
        codes, messages = _reason_meta(reasons, extra_messages)
    else:
        codes, messages = _reason_meta(reasons)

    debug = {"test_geom": asdict(geom), "std_geom": asdict(std_model.geom)}
    if not gate.passed:
        debug["inference_valid"] = False
    hm = None
    if cfg["anomaly"].get("enable_heatmap", True) and label != "OK":
        hm = anomaly_heatmap(polar, ds_T=int(cfg["anomaly"]["heatmap_downsample_T"]), ds_R=int(cfg["anomaly"]["heatmap_downsample_R"]))
        debug["anomaly_heatmap"] = hm

    # attach defect type when NG_PATTERN
    if label == "NG_PATTERN":
        dtype, conf, det = classify_defect(anom.scores, hm)
        anom.type = dtype
        anom.type_confidence = float(conf)
        anom.type_details = det

    decision = Decision(
        label=label,
        reasons=reasons,
        reason_codes=codes,
        reason_messages=messages,
        gate=gate,
        signature=sig,
        anomaly=anom,
        debug=debug,
        diagnostics=diagnostics,
        phase="INSPECTION",
    )
    _attach_v2_diagnostics(test_bgr, decision, cfg, ok_log_context)
    _append_ok_features(test_bgr, decision, cfg, pattern_baseline, ok_log_context)
    return decision


def evaluate_multi(
    test_bgr,
    std_models: Dict[str, Any],
    cfg: Dict[str, Any],
    pattern_baseline: Dict[str, Any] | None = None,
    ok_log_context: Dict[str, Any] | None = None,
) -> Tuple[Decision, Dict[str, SignatureResult]]:
    """
    Multi-mode evaluation for LOW/MID/HIGH (A-plan: shared cfg).
    Returns (Decision, mode_sigs).
    """
    geom = detect_lens_circle(test_bgr)
    gate = run_gate(
        geom, test_bgr,
        center_off_max=cfg["gate"]["center_off_max"],
        blur_min=cfg["gate"]["blur_min"],
        illum_max=cfg["gate"]["illum_max"],
    )
    diag_on_fail = bool(cfg.get("gate", {}).get("diagnostic_on_fail", False))

    if not gate.passed and not diag_on_fail:
        codes, messages = _reason_meta(gate.reasons)
        dec = Decision(
            label="RETAKE",
            reasons=gate.reasons,
            reason_codes=codes,
            reason_messages=messages,
            gate=gate,
            signature=None,
            anomaly=None,
            debug={"inference_valid": False},
            best_mode="",
            mode_scores={},
            phase="INSPECTION",
        )
        return dec, {}

    use_relative = bool(cfg.get("pattern_baseline", {}).get("use_relative", True))
    require_baseline = bool(cfg.get("pattern_baseline", {}).get("require", False))
    if require_baseline and use_relative and pattern_baseline is None:
        codes, messages = _reason_meta(["PATTERN_BASELINE_NOT_FOUND"])
        dec = Decision(
            label="RETAKE",
            reasons=["PATTERN_BASELINE_NOT_FOUND"],
            reason_codes=codes,
            reason_messages=messages,
            gate=gate,
            signature=None,
            anomaly=None,
            debug={"inference_valid": False, "baseline_missing": True},
            best_mode="",
            mode_scores={},
            phase="INSPECTION",
        )
        return dec, {}

    # Use geometry-based polar once (shared)
    any_model = next(iter(std_models.values()))
    polar = to_polar(test_bgr, geom, R=any_model.meta["R"], T=any_model.meta["T"])
    test_mean, _, _ = build_radial_signature(
        polar, r_start=cfg["signature"]["r_start"], r_end=cfg["signature"]["r_end"]
    )

    # Mode signatures
    mode_sigs: Dict[str, SignatureResult] = {}
    for mode, m in std_models.items():
        mode_sigs[mode] = _evaluate_signature(test_mean, m, cfg)

    best_mode = _pick_best_mode(mode_sigs)
    best_sig = mode_sigs[best_mode]

    # Anomaly once
    ang = angular_uniformity_score(polar, r_start=cfg["anomaly"]["r_start"], r_end=cfg["anomaly"]["r_end"])
    blobs = detect_center_blobs(test_bgr, geom, frac=cfg["anomaly"]["center_frac"], min_area=cfg["anomaly"]["center_blob_min_area"])
    if use_relative and pattern_baseline is not None:
        sample_features = extract_pattern_features(test_bgr, cfg=cfg)
        anom = score_anomaly_relative(
            sample_features=sample_features,
            baseline=pattern_baseline.get("features", {}),
            margins=pattern_baseline.get("policy", {}).get("margins", cfg.get("pattern_baseline", {}).get("margins", {})),
        )
        anom.debug["abs_scores"] = {"angular_uniformity": float(ang), "center_blob_count": float(blobs["blob_count"])}
        anom.debug["blob_debug"] = blobs
    else:
        anom = score_anomaly(
            angular_uniformity=ang,
            center_blob_count=int(blobs["blob_count"]),
            angular_unif_max=cfg["anomaly"]["angular_unif_max"],
            center_blob_max=cfg["anomaly"]["center_blob_max"],
            blob_debug=blobs,
        )

    label, reasons = decide(gate, best_sig, anom)
    test_lab_map = bgr_to_lab(polar)
    diagnostics, extra_codes, extra_messages = _compute_diagnostics(
        test_lab_map, std_models[best_mode].radial_lab_mean, cfg
    )
    if pattern_baseline is not None:
        diagnostics.setdefault("references", {})
        diagnostics["references"]["pattern_baseline_path"] = pattern_baseline.get("path", "")
        diagnostics["references"]["pattern_baseline_schema"] = pattern_baseline.get("schema_version", "")
        diagnostics["references"]["pattern_baseline_active_versions"] = pattern_baseline.get("active_versions", {})
    if label != "OK":
        reasons = reasons + extra_codes
        codes, messages = _reason_meta(reasons, extra_messages)
    else:
        codes, messages = _reason_meta(reasons)

    debug = {"test_geom": asdict(geom)}
    if not gate.passed:
        debug["inference_valid"] = False
    # include per-mode std geometry for traceability
    debug["std_geoms"] = {k: asdict(v.geom) for k, v in std_models.items()}

    hm = None
    if cfg["anomaly"].get("enable_heatmap", True) and label != "OK":
        hm = anomaly_heatmap(polar, ds_T=int(cfg["anomaly"]["heatmap_downsample_T"]), ds_R=int(cfg["anomaly"]["heatmap_downsample_R"]))
        debug["anomaly_heatmap"] = hm

    if label == "NG_PATTERN":
        dtype, conf, det = classify_defect(anom.scores, hm)
        anom.type = dtype
        anom.type_confidence = float(conf)
        anom.type_details = det

    mode_scores = {k: asdict(v) for k, v in mode_sigs.items()}

    dec = Decision(
        label=label,
        reasons=reasons,
        reason_codes=codes,
        reason_messages=messages,
        gate=gate,
        signature=best_sig,
        anomaly=anom,
        debug=debug,
        diagnostics=diagnostics,
        best_mode=best_mode,
        mode_scores=mode_scores,
        phase="INSPECTION",
    )
    _attach_v2_diagnostics(test_bgr, dec, cfg, ok_log_context)
    _append_ok_features(test_bgr, dec, cfg, pattern_baseline, ok_log_context)
    return dec, mode_sigs


def evaluate_registration_multi(test_bgr, std_models: Dict[str, Any], cfg: Dict[str, Any]) -> Decision:
    geom = detect_lens_circle(test_bgr)
    gate = run_gate(
        geom, test_bgr,
        center_off_max=cfg["gate"]["center_off_max"],
        blur_min=cfg["gate"]["blur_min"],
        illum_max=cfg["gate"]["illum_max"],
    )
    diag_on_fail = bool(cfg.get("gate", {}).get("diagnostic_on_fail", False))
    summary, unstable_modes = _registration_summary(std_models, cfg)

    label = "STD_ACCEPTABLE"
    reasons: list = []
    if not gate.passed:
        label = "STD_RETAKE"
        reasons = gate.reasons
    elif summary.get("order_enabled", True) and not summary.get("order_ok", False):
        label = "STD_UNSTABLE"
        reasons = ["MODE_ORDER_MISMATCH"]
    elif not summary.get("separation_ok", True):
        label = "STD_RETAKE"
        reasons = ["MODE_SEPARATION_LOW"]
    elif unstable_modes:
        label = "STD_RETAKE"
        reasons = [f"MODE_VARIANCE_HIGH:{m}" for m in unstable_modes]
    codes, messages = _reason_meta(reasons)

    debug = {"test_geom": asdict(geom), "std_geoms": {k: asdict(v.geom) for k, v in std_models.items()}}

    if gate.passed or diag_on_fail:
        any_model = next(iter(std_models.values()))
        polar = to_polar(test_bgr, geom, R=any_model.meta["R"], T=any_model.meta["T"])
        test_mean, _, _ = build_radial_signature(
            polar, r_start=cfg["signature"]["r_start"], r_end=cfg["signature"]["r_end"]
        )
        mode_sigs: Dict[str, SignatureResult] = {}
        for mode, m in std_models.items():
            mode_sigs[mode] = _evaluate_signature(test_mean, m, cfg)
        debug["signature_mode_scores"] = {k: asdict(v) for k, v in mode_sigs.items()}

        ang = angular_uniformity_score(polar, r_start=cfg["anomaly"]["r_start"], r_end=cfg["anomaly"]["r_end"])
        blobs = detect_center_blobs(test_bgr, geom, frac=cfg["anomaly"]["center_frac"], min_area=cfg["anomaly"]["center_blob_min_area"])
        anom = score_anomaly(
            angular_uniformity=ang,
            center_blob_count=int(blobs["blob_count"]),
            angular_unif_max=cfg["anomaly"]["angular_unif_max"],
            center_blob_max=cfg["anomaly"]["center_blob_max"],
            blob_debug=blobs,
        )
        debug["anomaly_debug"] = asdict(anom)
    else:
        debug["inference_valid"] = False

    return Decision(
        label=label,
        reasons=reasons,
        reason_codes=codes,
        reason_messages=messages,
        gate=gate,
        signature=None,
        anomaly=None,
        debug=debug,
        phase="STD_REGISTRATION",
        registration_summary=summary,
        best_mode="",
        mode_scores={},
    )
