from __future__ import annotations

from typing import Any, Dict, List, Tuple

import numpy as np


def _mean_lab(lab_samples: np.ndarray, labels: np.ndarray, k: int) -> List[np.ndarray]:
    means = []
    for i in range(k):
        idx = np.where(labels == i)[0]
        if idx.size == 0:
            means.append(np.array([0.0, 0.0, 0.0], dtype=np.float32))
        else:
            means.append(lab_samples[idx].mean(axis=0).astype(np.float32))
    return means


def _area_ratios(labels: np.ndarray, k: int) -> List[float]:
    total = float(labels.size)
    if total <= 0:
        return [0.0 for _ in range(k)]
    ratios = []
    for i in range(k):
        ratios.append(float(np.sum(labels == i) / total))
    return ratios


def separation_ab(mean_labs: List[np.ndarray], area_ratios: List[float]) -> Dict[str, float]:
    if len(mean_labs) < 2:
        return {"min_deltaE": 0.0, "mean_deltaE": 0.0}
    ab = np.array([[m[1], m[2]] for m in mean_labs], dtype=np.float32)
    dists = []
    weights = []
    for i in range(len(ab)):
        for j in range(i + 1, len(ab)):
            d = np.linalg.norm(ab[i] - ab[j])
            dists.append(float(d))
            weights.append(float(min(area_ratios[i], area_ratios[j])))
    if not dists:
        return {"min_deltaE": 0.0, "mean_deltaE": 0.0}
    w = np.array(weights, dtype=np.float32)
    w_sum = float(np.sum(w)) if w.size else 0.0
    if w_sum > 0:
        mean_w = float(np.sum(np.array(dists, dtype=np.float32) * w) / w_sum)
    else:
        mean_w = float(np.mean(dists))
    return {"min_deltaE": float(min(dists)), "mean_deltaE": mean_w}


def build_cluster_stats(lab_samples: np.ndarray, labels: np.ndarray, k: int) -> Dict[str, Any]:
    means = _mean_lab(lab_samples, labels, k)
    ratios = _area_ratios(labels, k)
    clusters = []
    for i in range(k):
        mean_lab = means[i]
        clusters.append({
            "area_ratio": float(ratios[i]),
            "mean_lab": mean_lab.tolist(),
            "mean_ab": [float(mean_lab[1]), float(mean_lab[2])],
        })
    sep = separation_ab(means, ratios)
    min_area = float(min(ratios)) if ratios else 0.0
    return {
        "clusters": clusters,
        "quality": {
            "min_area_ratio": min_area,
            "min_deltaE_between_clusters": sep["min_deltaE"],
            "mean_deltaE_between_clusters": sep["mean_deltaE"],
        },
    }
